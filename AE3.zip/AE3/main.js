var url;
var obj_form;
var currentPanel;

document.addEventListener('DOMContentLoaded',() =>{
    inicializar();

    
    
});

function inicializar(){



    currentPanel=1;
    document.getElementById("paso2").style.display="none";
    document.getElementById("paso3").style.display="none";
    document.getElementById("paso4").style.display="none";

    document.getElementById("botonAtras").style.cursor="none";
    document.getElementById("botonAtras").style.disabled=true;


}

function barraProgres(panel){
    document.getElementById("errores").innerHTML="";
    if(panel==0){

        document.getElementById("barra"+currentPanel).style.background="white";
        
        document.getElementById("paso"+currentPanel).style.display="none";
        currentPanel--;
        document.getElementById("paso"+currentPanel).style.display="block";


        document.getElementById("paso"+currentPanel).style.display="block";


    }else{
        document.getElementById("barra"+currentPanel).style.background="blue";
        if(currentPanel==2){
            
            obj_form = {
                nombre:document.getElementById("nombre").value,
                apellidos:document.getElementById("apellidos").value,
                fecha:document.getElementById("fecha").value,
                direccion:document.getElementById("direccion").value,
                codpostal:document.getElementById("codpostal").value,
                provincia:document.getElementById("provincia").value,
                municipio:document.getElementById("municipio").value

            };
            console.log(obj_form);


            var res = checkData();
            if(res !="" ){
                document.getElementById("errores").innerHTML=res;
                return false;
            }
            else formData();
        }

        

        document.getElementById("paso"+currentPanel).style.display="none";
        currentPanel++;
        document.getElementById("paso"+currentPanel).style.display="block";
        


    }

    
}

function checkData(){
    var error="";

  for (dato in obj_form){
        if(obj_form[dato]=="" || obj_form[dato]==null){
            error+=" - Falta el dato: "+dato+"</br>";
        }
    };

    return error;
}

function formData(){
    
    for (dato in obj_form){
        console.log(document.getElementById(dato));
        document.getElementById(dato+"PREV").value = obj_form[dato];
        document.getElementById(dato+"PREV").disabled = true;
   
    };

}
