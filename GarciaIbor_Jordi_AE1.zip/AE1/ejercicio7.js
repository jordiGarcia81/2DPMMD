//ejercicio 7:

num=-10;

function absoluto(num){
   let res= Math.abs(num);
    return res;
}

console.log("el numero "+num+"  su valor absoluto es: "+absoluto(num));
