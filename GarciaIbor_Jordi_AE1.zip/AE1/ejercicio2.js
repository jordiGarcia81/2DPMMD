// ejercicio 2:

let meses=["enero","feberero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"];
for(let i=0;i<meses.length;i++){
    console.warn(meses[i]);
    
}
console.table(meses);
