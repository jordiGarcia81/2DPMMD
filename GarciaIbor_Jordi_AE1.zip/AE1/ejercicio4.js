//ejercicio 4:

var numero1=5;
var numero2=8;

if(numero1 < numero2){
    console.log("numero 1 no es mayor que numero 2");
}

if(numero2 > 0){
    console.log("el numero 2 es positivo");
}

if(numero1 < 0 || numero1 !=0){
    console.log("el numero 1 es negativo o distinto a 0");
}

if(numero1 + 1 <= numero2){
    console.log(" incrementar en 1 unidad el valor de numero 1 no lo hace mayor o igual que numero 2");
}
