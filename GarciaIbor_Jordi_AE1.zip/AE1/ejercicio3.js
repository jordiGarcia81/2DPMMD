//ejercicio 3:

const values = [true, false, 5, "hola", [1,2,3], {age: 2, gender: 'male'}];

values[0]=Boolean;
values[1]=Boolean;
values[2]=Int16Array;
values[3]=String;
values[4]=Array;
values[5]=Object;

for(let i=0;i< values.length;i++){
    console.log(values[i]);
}