//ejercicio 5:

let num=15;
let total=1;
for(let i=1;i<num;i++){
    total=total * i;
}
console.log("el numero factorial de: "+num+" es: "+total);
