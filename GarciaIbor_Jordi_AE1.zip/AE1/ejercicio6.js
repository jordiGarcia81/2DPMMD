//ejercicio 6:

num=prompt("introduzca un numero: ");
function functionParImpar(num){
    if(num%2==0){
        return "el numero es par";
    }else{
        return "el numero es impar"
    }
}

console.log(functionParImpar(num));