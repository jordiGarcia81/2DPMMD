//ejercicio 1:

var ALERT_MESSAGE= "soy el primer script";
alert("soy el primer script  "+ ALERT_MESSAGE+ " y estoy funcionando sobre:  "+navigator.userAgent);